?php

$login = $_POST['login'];
$senha = MD5($_POST['senha']);
$connect = mysql_connect('','','');
$db = mysql_select_db('');
$query_select = "SELECT login FROM usuarios WHERE login = '$login'";
$select = mysql_query($query_select,$connect);
$array = mysql_fetch_array($select);
$logarray = $array['login'];

if($login == "" || $login == null){
echo"<script language='javascript' type='text/javascript'>
    alert('O campo login não deve ficar vazio');window.location.href='
    cadastro.html';</script>";

}else{
if($logarray == $login){

echo"<script language='javascript' type='text/javascript'>
    alert('login já existe');window.location.href='
    cadastro.html';</script>";
die();

}else{
$query = "INSERT INTO usuarios (login,senha) VALUES ('$login','$senha')";
$insert = mysql_query($query,$connect);

if($insert){
echo"<script language='javascript' type='text/javascript'>
    alert('Usuário cadastrado!');window.location.
        href='login.html'</script>";
}else{
echo"<script language='javascript' type='text/javascript'>
    alert('Não foi possível cadastrar');window.location
        .href='cadastro.html'</script>";
}
}
}
?>
