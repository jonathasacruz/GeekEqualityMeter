<?php
$login_cookie = $_COOKIE['login'];
if(isset($login_cookie)){
    echo"Bem-Vindo, $login_cookie <br>";
    echo"<font color='red'>LOGADO</font> ";
}else{
    echo"<font color='red'>VOCÊ NÃO ESTÁ LOGADO</font>";
    echo"<br><a href='login.html'>Faça Login</a> Para ter acesso ao conteúdo";
}
?>
